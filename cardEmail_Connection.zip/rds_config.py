#config file containing credentials for RDS MySQL instance
db_username = "aurora_db"
db_password = "B4N6JrgHYAFbKSg"
db_name = "aurora_db" 